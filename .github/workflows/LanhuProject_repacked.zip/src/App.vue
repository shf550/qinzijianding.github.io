<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="css" src="./assets/common.css">
</style>
