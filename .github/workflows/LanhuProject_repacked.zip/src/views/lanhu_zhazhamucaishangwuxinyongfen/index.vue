<template>
  <div class="page flex-col">
    <div class="group_1 flex-row">
      <div class="group_2 flex-col">
        <div class="box_1 flex-row">
          <img
            class="image_1"
            referrerpolicy="no-referrer"
            src="./assets/img/pschifd8yuae4tuco8hu28hoggwi23b52xp88c1f9a6-987b-4105-b728-4a82884df3d3.png"
          />
          <div class="block_1 flex-row justify-end">
            <img
              class="thumbnail_1"
              referrerpolicy="no-referrer"
              src="./assets/img/psis2rv5r2emj9vza1wapkys9zvmy5ozf4a753bc64-2ace-4816-9d78-c6e8f96a3ea5.png"
            />
            <span class="text_1">请输入企业名、人名等关键词查询</span>
            <div class="text-wrapper_1 flex-col"><span class="text_2">搜索</span></div>
          </div>
          <img
            class="label_1"
            referrerpolicy="no-referrer"
            src="./assets/img/pssnxixht29coizudlasgob9353le41tf36d5d3241a-d7bf-438e-ad18-4e7ed95736df.png"
          />
        </div>
        <div class="box_2 flex-col justify-end">
          <span class="text_3">黑名单商家请谨慎交易</span>
          <div class="block_2 flex-row justify-end">
            <div class="image-text_1 flex-row justify-between">
              <img
                class="label_2"
                referrerpolicy="no-referrer"
                src="./assets/img/psqvxw5i9phh8327qe5s8xrxd9zc2j3csn803194b59-3992-48e8-a690-5bc13c02d98f.png"
              />
              <span class="text-group_1">平台交易有保障，线上交易更便捷</span>
            </div>
            <div class="image-text_2 flex-row justify-between">
              <img
                class="label_3"
                referrerpolicy="no-referrer"
                src="./assets/img/ps8j7pgjvt3lc1huv4tkum7buhlf67e47n96b4c9192-8819-4f86-b322-042c1ee9e988.png"
              />
              <span class="text-group_2">平台交易有保障，线上交易更便捷</span>
            </div>
            <img
              class="label_4"
              referrerpolicy="no-referrer"
              src="./assets/img/pslu2c6cyxe82ndgdni78j120c98xqburt961483f6-421d-4d44-a7ab-293280fed593.png"
            />
            <span class="text_4">平台交易有保障，线上交易更便捷</span>
            <img
              class="image_2"
              referrerpolicy="no-referrer"
              src="./assets/img/ps4p2jl0ma6makvelyrxc8gm1bflvnrfdb27ec72e-8f88-4bdf-8602-9e9ff98627c8.png"
            />
          </div>
          <div class="block_3 flex-col">
            <div class="group_3 flex-col">
              <div class="box_3 flex-row">
                <div class="block_4 flex-col align-center">
                  <div class="image-wrapper_1 flex-col align-center">
                    <img
                      class="image_3"
                      referrerpolicy="no-referrer"
                      src="./assets/img/ps4ddd37czrr3xmlqsl020vmc14rfv964918efe32b-c4a1-43ab-87a4-18846a61fcd8.png"
                    />
                  </div>
                </div>
                <div class="block_5 flex-col">
                  <div class="block_6 flex-col"></div>
                  <div class="text-wrapper_2 flex-row">
                    <span class="text_5">为什么成为黑名单商家</span>
                    <span class="text_6">为什么成为黑名单商家</span>
                    <span class="text_7">为什么成为黑名单商家</span>
                  </div>
                  <img
                    class="image_4"
                    referrerpolicy="no-referrer"
                    src="./assets/img/psryag3pudytgy1w8zzfeukj0ugyzb13e0g18f18e0d-c4f4-4681-9bef-97ac059c5adc.png"
                  />
                  <div class="block_7 flex-col">
                    <span class="text_8">黑名单商家</span>
                    <img
                      class="thumbnail_2"
                      referrerpolicy="no-referrer"
                      src="./assets/img/psmc7msq9q82gcrhqhn7jj4vmzlp81ssyfbad05e0a-1d55-4d44-84f6-f27d56fffd28.png"
                    />
                  </div>
                  <div class="text-wrapper_3 flex-col">
                    <span class="text_9">汕头绿源木材加工厂2022-11-2611:48:55入驻真木网平台</span>
                  </div>
                </div>
                <div class="block_8 flex-col align-center">
                  <div class="image-wrapper_2 flex-col align-center">
                    <img
                      class="image_5"
                      referrerpolicy="no-referrer"
                      src="./assets/img/pskobemkvexlradug0z0how7evp4s9g4r9v8e609069-5391-45bd-99e3-c69526b9fe39.png"
                    />
                  </div>
                </div>
              </div>
              <div class="text-wrapper_4 flex-col">
                <span class="paragraph_1">
                  商家入驻真木网后，接单以后，发货多次出现了产品质量问题，
                  <br />
                  出现严重违规。
                </span>
              </div>
              <div class="box_4 flex-col">
                <div class="text-wrapper_5">
                  <span class="text_10">汕头绿源木材加工厂是</span>
                  <span class="text_11">黑名单商家</span>
                  <span class="text_12">，请谨慎与该商家交易</span>
                </div>
              </div>
            </div>
            <div class="group_4 flex-col"></div>
            <div class="text-wrapper_6 flex-col">
              <span class="text_13">2023-02-0111:35:23&nbsp;真木网平台已经取消与其合作</span>
            </div>
            <div class="group_5 flex-col">
              <div class="image-wrapper_3 flex-row">
                <img
                  class="thumbnail_3"
                  referrerpolicy="no-referrer"
                  src="./assets/img/ps9nekqv8exnd7y6rfg6jr3jo77lmx1icqf04ce3dd8-d730-4c9b-b7b9-0dc39c9b43a8.png"
                />
                <img
                  class="thumbnail_4"
                  referrerpolicy="no-referrer"
                  src="./assets/img/psvy0w5q784gfnpe4du2ugrjvx8j7cor2hf3f2e0c4-0ff7-4cc8-b309-075f83679dfd.png"
                />
                <img
                  class="thumbnail_5"
                  referrerpolicy="no-referrer"
                  src="./assets/img/psgzu6inlb88sya2a4gu5onij84y29bw8a79fb5cf-b84f-4ade-9b71-344d264e242a.png"
                />
              </div>
              <div class="image-wrapper_4 flex-row justify-between">
                <img
                  class="thumbnail_6"
                  referrerpolicy="no-referrer"
                  src="./assets/img/psgazplzlhrilf52xo5hsj59j0pvg5srhi44645ff8-f9b3-4bfa-a55a-75a6ec5fd050.png"
                />
                <img
                  class="thumbnail_7"
                  referrerpolicy="no-referrer"
                  src="./assets/img/psmz0hg8f1v0e689k47ami2eoyatwb2jj7acff6e7ec-1617-438e-b5b8-7068c35af7b0.png"
                />
              </div>
              <div class="image-wrapper_5 flex-row">
                <img
                  class="thumbnail_8"
                  referrerpolicy="no-referrer"
                  src="./assets/img/psckl349d2qyipdd5qr7ei7jfq3nl7921n686fdde5-8cf9-42ec-8412-db995bb51b2c.png"
                />
              </div>
              <div class="image-wrapper_6 flex-row">
                <img
                  class="thumbnail_9"
                  referrerpolicy="no-referrer"
                  src="./assets/img/psxegvwphv6bagxvj8pi8sim2pi96kily11f19582-9da1-422e-9ca4-8600ac8acc6a.png"
                />
              </div>
              <img
                class="thumbnail_10"
                referrerpolicy="no-referrer"
                src="./assets/img/pssj5xt9ximzi2wpv6y9k8tgzh1ox7ir0t18b530d8-7111-4fe5-9b5b-83a739293ea1.png"
              />
              <img
                class="thumbnail_11"
                referrerpolicy="no-referrer"
                src="./assets/img/pspcnqy4p62lrxg8ei5y4rpngrddsvkdfecb0c0f7b8-402b-4d5c-b396-edc0e02990c7.png"
              />
              <img
                class="thumbnail_12"
                referrerpolicy="no-referrer"
                src="./assets/img/psgy0igcpaijgi12ofeaa63saxw43s3x7x5a591dc4a-2653-42e7-84d8-38353885d8b4.png"
              />
              <img
                class="thumbnail_13"
                referrerpolicy="no-referrer"
                src="./assets/img/psmjwyur035dep5v4n0pmmps6dzi0z7nlb6db8d3d7-c49f-42cc-93bd-91c82be1a5f6.png"
              />
              <img
                class="image_6"
                referrerpolicy="no-referrer"
                src="./assets/img/psy6akftzgfnfuv9zp5apf9ob5qok731dpe3599bf5-6818-4cfa-af38-3137b26d88dd.png"
              />
            </div>
          </div>
          <div class="block_9 flex-col">
            <div class="box_5 flex-row">
              <div class="group_6 flex-col justify-between">
                <span class="text_14">汕头绿源木材加工厂</span>
                <div class="text-group_3 flex-col justify-between">
                  <span class="text_15">木材加工，人造板制造，人造板销</span>
                  <span class="text_16">售，软木制品制造，家具制造</span>
                </div>
              </div>
              <div class="group_7 flex-col">
                <div class="text-wrapper_7 flex-row justify-between">
                  <span class="text_17">联系电话：</span>
                  <span class="text_18">***********</span>
                </div>
                <div class="text-wrapper_8 flex-row"><span class="text_19">注册地址:</span></div>
              </div>
              <span class="paragraph_2">
                汕头市沐阳县胡集镇梁井村吴庄组205国
                <br />
                道边1号
              </span>
            </div>
            <div class="box_6 flex-row justify-between">
              <div class="text-group_4 flex-col justify-between">
                <span class="text_20">0</span>
                <span class="text_21">企业信用分</span>
              </div>
              <div class="box_7 flex-row">
                <span class="text_22">黑名单商家无法查看商品&nbsp;&nbsp;黑名单商家无法查看商品&nbsp;</span>
                <div class="text-wrapper_9 flex-col">
                  <span class="paragraph_3">
                    黑名单
                    <br />
                    商家
                  </span>
                </div>
              </div>
            </div>
            <div class="box_8 flex-col"></div>
          </div>
        </div>
      </div>
      <img
        class="image_7"
        referrerpolicy="no-referrer"
        src="./assets/img/pstmg7ba7s7jh487kv0is9sneuc0zakiw7r4e8e1949-5aa8-48ff-9b97-28aeabaf33c2.png"
      />
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      constants: {}
    };
  },
  methods: {}
};
</script>
<style scoped lang="css" src="./assets/index.css" />